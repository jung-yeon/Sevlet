package com.nhnacademy.servlet;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserRegisterFormServlet implements Command {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        return "/userInsert.jsp";
    }
}
