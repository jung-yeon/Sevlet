package com.nhnacademy.repository;

import com.nhnacademy.domain.Post;

import java.util.HashMap;
import java.util.List;

public class MapPostRepository implements PostRepository {
//    private HashMap<>
    @Override
    public long register(Post post) {
        return 0;
    }

    @Override
    public void modify(Post post) {

    }

    @Override
    public Post remove(long id) {
        return null;
    }

    @Override
    public Post getPost(long id) {
        return null;
    }

    @Override
    public List<Post> getPosts() {
        return null;
    }
}
