package com.nhnacademy.repository;

import com.nhnacademy.domain.User;

import javax.servlet.annotation.WebServlet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapUserRepository implements UserRepository{
    private static Map<String, User> store = new HashMap<>();

    @Override
    public void add(User user) {
        store.put(user.getId(),user);
    }

    @Override
    public void modify(User user) {

    }

    @Override
    public User remove(String id) {
        return null;
    }

    @Override
    public User getUser(String id) {
        return null;
    }

    @Override
    public List<User> getUsers() {
        return null;
    }
}
