package com.nhnacademy.domain;

import lombok.Data;
@Data
public class User {
    private final String id;
    private final String password;
    private final String name;
    private final String profileFileName;
}
