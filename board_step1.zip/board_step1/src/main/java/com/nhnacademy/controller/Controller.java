package com.nhnacademy.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface Controller {
    //모든 Controller 클래스들이 반드시 재정의 해야하며, 컨트 롤러의 기능을 구현함
    public void execute(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException;
}
