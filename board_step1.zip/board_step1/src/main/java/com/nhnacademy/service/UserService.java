//package com.nhnacademy.service;
//
//import com.nhnacademy.vo.UserVO;
//
//public class UserService {
//    //객체를 한개만 생성해서 사용
//    //외부에서 값을 수정하는 것을 막기 위해 private
//    private static UserService service = new UserService();
//    public UserDAO dao = UserDAO.getInstance();
//
//    //외부에서 값을 수정하는 것을 막기 위해 private
//    //객체를 생성
//    private UserService(){}
//    public static UserService getInstance(){
//        return service;
//    }
//    public void userInsert(UserVO user){
//        dao.userInsert(user);
//    }
//}
