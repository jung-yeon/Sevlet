package repository;
import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;


class MapUserRepositoryTest {
    MapUserRepository userRepository = MapUserRepository.getInstance();
    @Test
    void add() {

        //given
        User user = new User("hello", "w", "ko","file");

//        //when
//        String savedMember = (User) userRepository.add(user);
//        //then
//        User findMember = userRepository.getUser(savedMember.getId());
//        assertThat(findMember).isEqualTo(savedMember);
    }
    @Test
    void findAll() {

        //given
        User user1 = new User("member1","2","3","4");
        User user2 = new User("member2","2","3","4");

        userRepository.add(user1);
        userRepository.add(user2);

        //when
        List<User> result = userRepository.getUsers();


        System.out.println(result);
        //then
        assertThat(result.size()).isEqualTo(2);
        assertThat(result).contains(user1, user2);
    }
}




