package com.nhnacademy.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Post {
    private long id;
    private String title;
    private String content;
    private String writerUserId;
    private LocalDateTime writeTime;

//    int getViewCount();
//    void increaseViewCount();
}
