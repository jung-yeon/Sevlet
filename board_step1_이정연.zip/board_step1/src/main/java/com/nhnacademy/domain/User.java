package com.nhnacademy.domain;

import lombok.Data;

@Data
public class User {
    private static final User userInstance = new User();

    private String id;
    private String password;
    private String name;
    private String profileFileName;



    public User(String id, String password, String name, String profileFileName) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.profileFileName = profileFileName;
    }

    public User() {

    }

    public static User getInstance(){

        return userInstance;
    }

//    String getId();
//    void setId(String id);
//
//    String getPassword();
//    void setPassword(String password);
//
//    String getName();
//    void setName(String name);
//
//    String getProfileFileName();
//    void setProfileFileName(String profileFileName);
}
