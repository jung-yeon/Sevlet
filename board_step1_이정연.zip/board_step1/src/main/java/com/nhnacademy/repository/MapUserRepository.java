package com.nhnacademy.repository;

import com.nhnacademy.domain.User;

import javax.servlet.annotation.WebServlet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapUserRepository implements UserRepository{
    private static Map<String, User> storeMap = new HashMap<>();
    private static final MapUserRepository instance = new MapUserRepository();
    private MapUserRepository() {
    }
    public static MapUserRepository getInstance(){
        return instance;
    }
    @Override
    public void add(User user) {
        storeMap.put(user.getId(), user);
    }

    @Override
    public void modify(User user) {

    }

    @Override
    public User remove(String id) {
        return null;
    }

    @Override
    public User getUser(String id) {
        User user = null;
        for(int i = 0; i<storeMap.size(); i++){
            if(storeMap.get(i).getId().equals(id)){
                user = storeMap.get(i);
            }
        }
        return user;
    }

    @Override
    public List<User> getUsers() {
        return new ArrayList<>(storeMap.values());
    }
    public Map<String, User> getMaps(){
        return storeMap;
    }
}
