package com.nhnacademy.controller;

import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;
import com.nhnacademy.repository.UserRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserSearchController implements Controller {
    private MapUserRepository userRepository = MapUserRepository.getInstance();
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        //NullPointerException
//        UserRepository userRepository = (UserRepository) request.getServletContext().getAttribute("userRepository");
        User user = User.getInstance();


        if (id.isEmpty()) {
            request.setAttribute("error", "ID를 입력해주시기 바랍니다.");
            HttpUtil.forward(request, response, "/userSearch/userSearch.jsp");
            return;
        }

       else if (user.getId().equals(id)) {
            request.setAttribute("id", user.getId());
            request.setAttribute("name", user.getName());
            request.setAttribute("profileFileName", user.getProfileFileName());
            HttpUtil.forward(request, response, "/result/userSearchOutput.jsp");
        }

    }
}
