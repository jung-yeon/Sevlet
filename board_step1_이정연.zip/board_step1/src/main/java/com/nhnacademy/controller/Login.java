package com.nhnacademy.controller;

import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;
import com.nhnacademy.repository.UserRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class Login implements Controller {
    private MapUserRepository userRepository = MapUserRepository.getInstance();
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String password = request.getParameter("password");

        User user = User.getInstance();

        //유효성 체크
        if (id.isEmpty() || password.isEmpty()) {
            request.setAttribute("error", "모든 항목을 빠짐없이 입력해 주세요");
            HttpUtil.forward(request, response, "/login/login.jsp");
            return;
        }
        try{
            for(int i = 0; i<userRepository.getUsers().size(); i++){
                if(userRepository.getUsers().get(i).getId().equals(id)){
                    request.setAttribute("error", "이미 존재하는 ID 입니다.");
                }
                else{
                    HttpSession session = request.getSession();
                    session.setAttribute("sessionId", id);
                    session.setAttribute("sessionPwd", password);

                    request.setAttribute("id", id);

                    HttpUtil.forward(request, response, "/result/loginOutput.jsp");
                }
            }
        }catch (NullPointerException e){
            System.out.println("nothing");
            request.setAttribute("error", "회원정보가 없습니다.");
            HttpUtil.forward(request, response, "/login/login.jsp");
        }

//        else if(userRepository.getUsers())
//        else if(userRepository.getUser(id).equals(id) && userRepository.getUsers().equals(password)){
//            HttpSession session = request.getSession();
//            session.setAttribute("sessionId", id);
//            session.setAttribute("sessionPwd", password);
//
//            request.setAttribute("id", id);
//
//            HttpUtil.forward(request, response, "/result/loginOutput.jsp");
//        }else{
//            request.setAttribute("error", "회원 정보가 없습니다." + "'\n'" + "회원 가입을 하시려면 회원가입 버튼을 눌러 가입해주세요");
//            HttpUtil.forward(request, response, "/login/login.jsp");
//        }

    }
}
