package com.nhnacademy.controller;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;


public class FrontController extends HttpServlet {
    private  static final long serialVersionUID = 1L;
    String charset = null;
    HashMap<String, Controller> list = null;


    //현재 서블릿 객체가 최초로 요청이 들어왔을 때 한번만 실행되는 메소드 [서블릿의 초기화 기능 담당]
    @Override
    public void init(ServletConfig config) throws ServletException {
        charset = config.getInitParameter("charset");
        list = new HashMap<String, Controller>();
        list.put("/userInsert.do", new UserInsertController());
        list.put("/userSearch.do", new UserSearchController());
        list.put("/userUpdate.do", new UserUpdateController());
        list.put("/userDelete.do", new UsetDeleteController());
        list.put("/login.do", new Login());
        list.put("/logout.do", new LogOut());
    }


    //클라이언트로 부터 요청이 들어올 때마다 실행하는 메소드
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding(charset);
        /*
           ex) htp://localhost:8080/nhnacademy/UserInsert.do이면 각 메소드의 결과값
           req.getRequestURI() -> /nhnacademy/UserInsert.do
           req.getContextPath() -> /nhnacademy
           contextPath.length() -> 4
           url.substring(4)     -> /UserInsert.do
           /UserInsert.do라면 이에 해당하는 value는 UserInsertController객체가 함
         */

        String url = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = url.substring(contextPath.length());
        Controller subController = list.get(path);
        subController.execute(req,resp);
    }
}
