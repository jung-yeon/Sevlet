package com.nhnacademy.controller;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
public class HttpUtil {
    //다른 페이지로 이동하기 위한 기능
    public static void forward(HttpServletRequest request, HttpServletResponse response, String path){
        try{
            RequestDispatcher rd = request.getRequestDispatcher(path);
            rd.forward(request, response);
        }catch (Exception ex){
            log.error("error : ",ex);
        }
    }
}
