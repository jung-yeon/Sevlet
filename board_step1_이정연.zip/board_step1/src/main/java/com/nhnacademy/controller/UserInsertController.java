package com.nhnacademy.controller;

import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserInsertController implements Controller {
    private MapUserRepository userRepository = MapUserRepository.getInstance();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user;
        String id = request.getParameter("id");

        user = new User(request.getParameter("id"),
                request.getParameter("password"),
                request.getParameter("name"),
                request.getParameter("profileFileName"));


        //유효성 체크
        if (user.getId().isEmpty() || user.getPassword().isEmpty() || user.getName().isEmpty() || user.getProfileFileName().isEmpty()) {
            request.setAttribute("error", "모든 항목을 빠짐없이 입력해 주세요");
            // 입력 페이지인 /userInsert.jsp로 이동후 return을 만나면 현재 메소드 종료
            HttpUtil.forward(request, response, "/userInsert/userInsert.jsp");
            return;
        }
//        if(userRepository.getUser(id).equals(id)){
//
//        }

        userRepository.add(user);
        System.out.println(userRepository.getUsers());


        //OUTPUT View 페이지로 이동
        request.setAttribute("id", id);
        HttpUtil.forward(request, response, "/result/userInsertOutput.jsp");
    }
}
