package com.nhnacademy.controller;

import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserUpdateController implements Controller {
    private MapUserRepository userRepository = MapUserRepository.getInstance();
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        User user = User.getInstance();
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String profileFileName = request.getParameter("profile");

        if((id!=null)){
            user.setId(id);
        }if(name != null){
            user.setName(name);
        }if(password != null){
            user.setPassword(password);
        }if(profileFileName != null){
            user.setProfileFileName(profileFileName);
        }
        request.setAttribute("id",user.getId());
        request.setAttribute("password",user.getPassword());
        request.setAttribute("name",user.getName());
        request.setAttribute("profile",user.getProfileFileName());
        HttpUtil.forward(request, response, "/result/userUpdateOutput.jsp");


    }
}
