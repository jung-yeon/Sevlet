package com.nhnacademy.controller;

import com.nhnacademy.domain.User;
import com.nhnacademy.repository.MapUserRepository;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LogOut  implements Controller {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        if(session == null){
            request.setAttribute("error", "로그인 먼저 해주세요.");
            HttpUtil.forward(request,response,"login/login.jsp");
        }
        else{
            session.invalidate();
            request.setAttribute("logout", "로그아웃 되었습니다.");
            HttpUtil.forward(request,response,"result/logoutOutput.jsp");
        }

    }
}
