package com.nhnacademy.servlet;

import javax.servlet.http.HttpServlet;
import java.net.http.HttpClient;

public class LoginServlet extends HttpServlet {
}
